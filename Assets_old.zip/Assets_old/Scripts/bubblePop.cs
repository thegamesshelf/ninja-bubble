﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bubblePop : MonoBehaviour
{
    [SerializeField] GameObject bubblePopPS;
    [SerializeField] GameObject bubble;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "ThrowingStar")
        {
            //print(collision.tag);
            //hide bubble image
            bubble.SetActive(false);
            // ignore the hit force from the star
            Physics2D.IgnoreCollision(collision.gameObject.GetComponent<Collider2D>(), bubble.GetComponent<Collider2D>());
            // get the particle system duration
            ParticleSystem parts = bubblePopPS.GetComponent<ParticleSystem>();
            //play particle system
            bubblePopPS.SetActive(true);
            //destroy after the particle system is done
            Destroy(gameObject, parts.main.duration+(parts.main.duration /3));
        }
    }

}
