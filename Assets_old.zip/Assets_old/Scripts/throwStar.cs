﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class throwStar : MonoBehaviour
{

    [SerializeField] Transform firePoint;
    [SerializeField] GameObject throwingStarPrefab;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1")) {
            Shoot();
        }
    }

    void Shoot() {
        Instantiate(throwingStarPrefab, firePoint.position, firePoint.rotation);
    }
}
